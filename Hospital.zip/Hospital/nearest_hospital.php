<?php 
require_once('functions/api.php');
{
    //echo @$_POST['email'],@$_POST['password'];
    //echo "<script> window.alert('sending'); </script>";
    //echo "sending";
    $res=$api->nearest_hospital();
}
?>